# JARVIS Android v1

A small voice-controlled Android companion. It uses Android's speech recognition service and launches installed apps whose launcher label matches the command.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on your phone.

## Example commands
- Open YouTube
- Launch WhatsApp
- Start Chrome
- Open Maps

This version intentionally does not include hidden surveillance or unauthorized device access. Later versions can add authenticated device pairing, remote actions, and an explicit Security Mode for devices you own or administer.
