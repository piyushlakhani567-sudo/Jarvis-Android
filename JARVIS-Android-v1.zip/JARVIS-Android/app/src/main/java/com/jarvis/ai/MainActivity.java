package com.jarvis.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 20;
    private static final int REQ_SPEECH = 21;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 32);
        root.setBackgroundColor(0xFF070B12);

        TextView title = new TextView(this);
        title.setText("J A R V I S"); title.setTextColor(0xFF62D8FF); title.setTextSize(30); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 70));

        TextView sub = new TextView(this);
        sub.setText("PERSONAL ANDROID ASSISTANT"); sub.setTextColor(0xFF8AA4B5); sub.setTextSize(12); sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 45));

        status = new TextView(this);
        status.setText("Ready. Try:  Open YouTube"); status.setTextColor(0xFFEAF8FF); status.setTextSize(18); status.setPadding(28, 28, 28, 28);
        status.setBackgroundColor(0xFF101827);
        root.addView(status, new LinearLayout.LayoutParams(-1, 0, 1));

        Button mic = new Button(this);
        mic.setText("🎙  TALK TO JARVIS"); mic.setTextSize(16); mic.setTextColor(0xFFEAF8FF); mic.setAllCaps(false);
        mic.setOnClickListener(v -> listen());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 68); bp.topMargin = 24; root.addView(mic, bp);

        TextView hint = new TextView(this);
        hint.setText("Examples:  open WhatsApp  •  launch Chrome  •  open Maps"); hint.setTextColor(0xFF8AA4B5); hint.setTextSize(12); hint.setGravity(Gravity.CENTER); hint.setPadding(0, 18, 0, 0);
        root.addView(hint, new LinearLayout.LayoutParams(-1, 55));
        setContentView(root);
    }

    private void listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell JARVIS what to do");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (Exception e) { Toast.makeText(this, "Speech recognition is not available", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SPEECH || resultCode != RESULT_OK || data == null) return;
        ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (r != null && !r.isEmpty()) execute(r.get(0));
    }

    private void execute(String command) {
        String q = command.toLowerCase(Locale.ROOT).trim();
        status.setText("Heard: “" + command + "”\\n\\nProcessing...");
        String target = q.replaceFirst("^(hey\\s+)?jarvis[ ,]*", "").trim();
        target = target.replaceFirst("^(please\\s+)?(open|launch|start|run)\\s+", "").trim();
        if (target.isEmpty()) { status.setText("Please say an app name, for example: open YouTube"); return; }

        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null); launcher.addCategory(Intent.CATEGORY_LAUNCHER); launcher.setPackage(null);
        List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(launcher, 0);
        for (android.content.pm.ResolveInfo ri : apps) {
            CharSequence label = ri.loadLabel(pm);
            if (label != null && (label.toString().toLowerCase(Locale.ROOT).equals(target) || label.toString().toLowerCase(Locale.ROOT).contains(target))) {
                ActivityInfo ai = ri.activityInfo;
                Intent open = new Intent(Intent.ACTION_MAIN); open.addCategory(Intent.CATEGORY_LAUNCHER); open.setClassName(ai.packageName, ai.name); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(open); status.setText("JARVIS: Opening " + label); return;
            }
        }
        status.setText("I couldn't find an installed app matching “" + target + "”.");
    }
}
